#include <SPI.h>
#include <MFRC522.h>
#define RFID_SS 5
#define RFID_RST 27
MFRC522 rfid(RFID_SS, RFID_RST);
void setup() {
  Serial.begin(115200);
  SPI.begin(18, 19, 23, RFID_SS);
  rfid.PCD_Init();
  Serial.println("Scan an RFID card; UID will appear below.");
}
void loop() {
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) return;
  Serial.print("Card UID:");
  for (byte i = 0; i < rfid.uid.size; i++) {
    Serial.print(' ');
    if (rfid.uid.uidByte[i] < 0x10) Serial.print('0');
    Serial.print(rfid.uid.uidByte[i], HEX);
  }
  Serial.println();
  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
}
