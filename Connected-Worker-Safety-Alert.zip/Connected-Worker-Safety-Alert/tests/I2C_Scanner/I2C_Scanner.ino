#include <Wire.h>
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  Serial.println("I2C scanner starting");
}
void loop() {
  byte found = 0;
  for (byte address = 1; address < 127; address++) {
    Wire.beginTransmission(address);
    if (Wire.endTransmission() == 0) {
      Serial.print("Found I2C device at 0x");
      if (address < 16) Serial.print('0');
      Serial.println(address, HEX);
      found++;
    }
  }
  if (!found) Serial.println("No I2C devices found. Check power, GND, SDA and SCL.");
  Serial.println("Scan complete; repeating in 3 seconds.\n");
  delay(3000);
}
