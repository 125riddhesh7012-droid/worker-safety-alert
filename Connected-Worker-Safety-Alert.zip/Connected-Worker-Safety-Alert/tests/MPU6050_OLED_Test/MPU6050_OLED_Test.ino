#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
Adafruit_MPU6050 mpu;
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED not found at 0x3C. Try 0x3D if scanner shows that address.");
  } else {
    display.clearDisplay(); display.setTextColor(SSD1306_WHITE); display.setTextSize(1);
    display.setCursor(0, 0); display.println("OLED working"); display.display();
  }
  if (!mpu.begin(0x68, &Wire)) Serial.println("MPU6050 not found at default address 0x68.");
  else Serial.println("MPU6050 working.");
}
void loop() {
  sensors_event_t a, g, t;
  if (mpu.getEvent(&a, &g, &t)) {
    Serial.printf("Accel m/s^2: %.2f, %.2f, %.2f\n", a.acceleration.x, a.acceleration.y, a.acceleration.z);
    display.clearDisplay(); display.setCursor(0, 0); display.setTextColor(SSD1306_WHITE);
    display.println("MPU6050 working");
    display.printf("X: %.1f\nY: %.1f\nZ: %.1f", a.acceleration.x, a.acceleration.y, a.acceleration.z);
    display.display();
  }
  delay(500);
}
