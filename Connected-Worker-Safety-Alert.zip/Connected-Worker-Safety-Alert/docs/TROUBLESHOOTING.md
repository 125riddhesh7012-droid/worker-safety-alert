# Troubleshooting

## OLED stays blank
1. Disconnect USB before changing wires.
2. Test only OLED: VCC→3V3, GND→GND, SDA→GPIO21, SCL→GPIO22.
3. Upload `tests/I2C_Scanner/I2C_Scanner.ino` and open Serial Monitor at 115200.
4. If the scanner reports `0x3D`, change `OLED_ADDRESS` / display address from `0x3C` to `0x3D`.
5. If no device appears, check labels and try known-good jumper wires.

## RFID reader does not scan
- Check RC522 is powered from 3V3, not 5V.
- Confirm SS/SDA→GPIO5, SCK→18, MISO→19, MOSI→23, RST→27.
- Upload `tests/RFID_Test/RFID_Test.ino` first.

## MPU6050 not detected
- OLED and MPU6050 share GPIO21/22 and can share the I2C bus.
- Check 3V3 and GND; run the I2C scanner and look for an address commonly `0x68` (some boards use `0x69`).

## Microphone triggers constantly or never triggers
- Check INMP441 wiring and L/R→GND.
- Observe `Microphone average level` in Serial Monitor while the room is quiet and while making a test sound.
- Set `SOUND_THRESHOLD` above normal quiet-room values but below the sound level you want to detect. This is a raw level threshold and varies by microphone board and room.

## Upload succeeds but nothing happens
- Select the correct ESP32 board and COM port.
- Open Serial Monitor at 115200 baud after upload.
- Test modules individually before connecting all modules.
- Disconnect the buzzer or other external wiring if the ESP32 resets unexpectedly.
