/*
  Connected Worker Safety Alert
  Board: ESP32 DevKit (classic ESP32)
  Sensors: RC522 RFID, MPU6050, INMP441 I2S microphone, I2C OLED

  IMPORTANT:
  - Change AUTHORIZED_UID to your own RFID card UID after reading it from Serial Monitor.
  - Sound threshold and motion threshold are starter values; calibrate for your environment.
  - This is a prototype, not certified life-safety equipment.
  - Uses the legacy ESP32 I2S driver API available in many Arduino-ESP32 2.x/3.x installs.
*/

#include <Wire.h>
#include <SPI.h>
#include <MFRC522.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include "driver/i2s.h"

// ---------- Pin configuration ----------
static const int I2C_SDA = 21;
static const int I2C_SCL = 22;
static const int RFID_SS = 5;
static const int RFID_RST = 27;
static const int BUZZER_PIN = 4;
static const int BUTTON_PIN = 32;
static const int I2S_BCLK = 26; // INMP441 SCK
static const int I2S_WS = 25;   // INMP441 WS/LRCL
static const int I2S_DIN = 33;  // INMP441 SD

// ---------- OLED ----------
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define OLED_ADDRESS 0x3C // Change to 0x3D if your scanner finds 0x3D
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
bool oledReady = false;

// ---------- Sensors ----------
MFRC522 rfid(RFID_SS, RFID_RST);
Adafruit_MPU6050 mpu;
bool mpuReady = false;
bool micReady = false;

// Replace this example UID with your own card UID (hex bytes, no spaces).
// Example: card UID A1 B2 C3 D4 -> {0xA1, 0xB2, 0xC3, 0xD4}
const byte AUTHORIZED_UID[] = {0xDE, 0xAD, 0xBE, 0xEF};
const byte AUTHORIZED_UID_LENGTH = sizeof(AUTHORIZED_UID);

// ---------- Tune these values after testing ----------
const float MOTION_DELTA_MPS2 = 3.5f; // change from normal gravity magnitude
const int SOUND_THRESHOLD = 180000;  // starter value; observe Serial output to calibrate
const unsigned long ALERT_DURATION_MS = 2500;
const unsigned long SENSOR_INTERVAL_MS = 100;

bool accessGranted = false;
unsigned long accessGrantedAt = 0;
unsigned long lastSensorRead = 0;
unsigned long lastSoundLog = 0;
String currentStatus = "System starting";

void showStatus(const String &line1, const String &line2 = "") {
  if (!oledReady) return;
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("CONNECTED WORKER");
  display.println("SAFETY ALERT");
  display.drawLine(0, 19, 127, 19, SSD1306_WHITE);
  display.setCursor(0, 27);
  display.println(line1);
  if (line2.length()) display.println(line2);
  display.display();
}

void beep(unsigned int durationMs = 250) {
  digitalWrite(BUZZER_PIN, HIGH);
  delay(durationMs);
  digitalWrite(BUZZER_PIN, LOW);
}

void raiseAlert(const String &reason) {
  currentStatus = "ALERT: " + reason;
  Serial.println(currentStatus);
  showStatus("SAFETY ALERT!", reason);
  for (int i = 0; i < 3; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(160);
    digitalWrite(BUZZER_PIN, LOW);
    delay(120);
  }
}

bool isAuthorizedCard() {
  if (rfid.uid.size != AUTHORIZED_UID_LENGTH) return false;
  for (byte i = 0; i < AUTHORIZED_UID_LENGTH; i++) {
    if (rfid.uid.uidByte[i] != AUTHORIZED_UID[i]) return false;
  }
  return true;
}

void printCardUID() {
  Serial.print("Card UID:");
  for (byte i = 0; i < rfid.uid.size; i++) {
    Serial.print(' ');
    if (rfid.uid.uidByte[i] < 0x10) Serial.print('0');
    Serial.print(rfid.uid.uidByte[i], HEX);
  }
  Serial.println();
}

void checkRFID() {
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) return;
  printCardUID();
  if (isAuthorizedCard()) {
    accessGranted = true;
    accessGrantedAt = millis();
    currentStatus = "Access granted";
    Serial.println("Access granted");
    showStatus("Access granted", "Worker identified");
    beep(100);
  } else {
    Serial.println("Access denied - unknown card");
    showStatus("Access denied", "Unknown RFID card");
    beep(500);
  }
  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
}

void setupMicrophone() {
  i2s_config_t config = {};
  config.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX);
  config.sample_rate = 16000;
  config.bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT;
  config.channel_format = I2S_CHANNEL_FMT_ONLY_LEFT;
  config.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  config.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  config.dma_buf_count = 4;
  config.dma_buf_len = 256;
  config.use_apll = false;
  config.tx_desc_auto_clear = false;
  config.fixed_mclk = 0;

  esp_err_t result = i2s_driver_install(I2S_NUM_0, &config, 0, NULL);
  if (result != ESP_OK) {
    Serial.printf("I2S driver install failed: %d\n", (int)result);
    micReady = false;
    return;
  }

  i2s_pin_config_t pins = {};
  pins.bck_io_num = I2S_BCLK;
  pins.ws_io_num = I2S_WS;
  pins.data_out_num = I2S_PIN_NO_CHANGE;
  pins.data_in_num = I2S_DIN;
  result = i2s_set_pin(I2S_NUM_0, &pins);
  if (result != ESP_OK) {
    Serial.printf("I2S pin setup failed: %d\n", (int)result);
    micReady = false;
    return;
  }
  i2s_zero_dma_buffer(I2S_NUM_0);
  micReady = true;
  Serial.println("INMP441 I2S microphone initialized");
}

void checkMicrophone() {
  if (!micReady) return;
  int32_t samples[128];
  size_t bytesRead = 0;
  esp_err_t result = i2s_read(I2S_NUM_0, samples, sizeof(samples), &bytesRead, 20 / portTICK_PERIOD_MS);
  if (result != ESP_OK || bytesRead < sizeof(int32_t)) return;

  size_t count = bytesRead / sizeof(int32_t);
  uint64_t total = 0;
  for (size_t i = 0; i < count; i++) {
    int32_t sample = samples[i] >> 8; // reduce 24-bit microphone data to a useful range
    total += (uint64_t)abs(sample);
  }
  int32_t average = (int32_t)(total / count);

  if (millis() - lastSoundLog > 1000) {
    Serial.printf("Microphone average level: %ld (threshold %d)\n", (long)average, SOUND_THRESHOLD);
    lastSoundLog = millis();
  }
  if (average > SOUND_THRESHOLD) {
    raiseAlert("Loud sound detected");
  }
}

void checkMotion() {
  if (!mpuReady) return;
  sensors_event_t a, g, temp;
  if (!mpu.getEvent(&a, &g, &temp)) return;
  float magnitude = sqrtf(a.acceleration.x * a.acceleration.x +
                          a.acceleration.y * a.acceleration.y +
                          a.acceleration.z * a.acceleration.z);
  float delta = fabsf(magnitude - 9.81f);
  if (delta > MOTION_DELTA_MPS2) {
    Serial.printf("Motion event: acceleration magnitude %.2f m/s^2\n", magnitude);
    raiseAlert("Abnormal motion");
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  Wire.begin(I2C_SDA, I2C_SCL);
  oledReady = display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDRESS);
  if (oledReady) showStatus("Starting sensors...");
  else Serial.println("OLED not found. Check I2C wiring/address 0x3C or 0x3D.");

  SPI.begin(18, 19, 23, RFID_SS); // SCK, MISO, MOSI, SS
  rfid.PCD_Init();
  Serial.println("RC522 initialized; scan a card to print its UID.");

  mpuReady = mpu.begin(0x68, &Wire);
  if (mpuReady) {
    mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
    Serial.println("MPU6050 initialized");
  } else {
    Serial.println("MPU6050 not found. Check 3V3/GND/SDA/SCL.");
  }

  setupMicrophone();
  showStatus("System ready", "Scan RFID / monitor");
  Serial.println("Connected Worker Safety Alert ready.");
  Serial.println("Set AUTHORIZED_UID in the sketch to your card UID before using access control.");
}

void loop() {
  checkRFID();

  if (digitalRead(BUTTON_PIN) == LOW) {
    delay(30); // simple debounce
    if (digitalRead(BUTTON_PIN) == LOW) {
      raiseAlert("Manual help button");
      while (digitalRead(BUTTON_PIN) == LOW) delay(10);
    }
  }

  checkMicrophone();

  if (millis() - lastSensorRead >= SENSOR_INTERVAL_MS) {
    lastSensorRead = millis();
    checkMotion();
  }

  if (accessGranted && millis() - accessGrantedAt > ALERT_DURATION_MS) {
    accessGranted = false;
    currentStatus = "System ready";
    showStatus("System ready", "Scan RFID / monitor");
  }
  delay(5);
}
